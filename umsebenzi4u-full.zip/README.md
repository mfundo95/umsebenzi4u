# Umsebenzi 4 U — Job Matching Website

## Overview
Umsebenzi 4 U is a South African job platform connecting employers and job seekers.
It features user registration, role-based dashboards, job posting, applying, profile editing, and messaging.

## Project Structure
- index.html — Home page with registration and login forms
- employer-dashboard.html — Employer dashboard for posting and managing jobs
- jobseeker-dashboard.html — Job seeker dashboard for browsing and applying jobs
- profile.html — User profile editing
- chat.html — Messaging between job seekers and employers

## Firebase Setup
1. Create a Firebase project at https://console.firebase.google.com
2. Enable Authentication with Email/Password
3. Enable Firestore Database in test mode
4. Replace Firebase config in all HTML files with your project's config

## Hosting Instructions (Firebase)
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

## Support
Built for South African youth by Umsebenzi 4 U.
